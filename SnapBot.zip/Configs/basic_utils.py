snapcap_responses = [
    "Snap upni biwi ko divorce mat de",
    "Papa came back with the milk",
    "Papa mene blackie se shadi kar li",
    "Snap did you adopt again?",
    "Snap Manno ka pankha wapas karde",
    "I love you too",
    "We should sleep together",
    "I can heal you",
    "Me looking for a fuck I'm supposed to give",
    "snapbot better",
    "talk to me babygurl"
]

greeting_responses = [
    "Hey there!",
    "Hi!",
    "Hello!",
    "Hey!",
    "Hi, how are you?",
    "Hello, good to see you!",
    "Hey, what's up?",
    "Hi, nice to meet you!",
    "Hello, how have you been?",
    "Hey, how's it going?",
    "Hi, how's your day?",
    "Hello, how are things?",
    "Hey, long time no see!",
    "Hi there, how can I help you?",
    "Hello, what's new?",
    "Hey, howdy!",
    "Hi, good to hear from you!",
    "Hello, nice weather today, isn't it?",
    "Hey, how's everything going?",
    "Hi, what's going on?"
]